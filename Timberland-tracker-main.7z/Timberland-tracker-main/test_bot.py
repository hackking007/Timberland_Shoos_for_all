#!/usr/bin/env python3
"""
סקריפט בדיקה מהיר לבוט טימברלנד
"""

import os
import json
from config import *

def test_config():
    """בדיקת קובץ ההגדרות"""
    print("🔧 בודק הגדרות...")
    
    if not TELEGRAM_TOKEN:
        print("❌ TELEGRAM_TOKEN לא מוגדר")
        return False
    
    print(f"✅ טוקן טלגרם: {TELEGRAM_TOKEN[:10]}...")
    
    if ADMIN_CHAT_ID:
        print(f"✅ צ'אט מנהל: {ADMIN_CHAT_ID}")
    else:
        print("ℹ️ צ'אט מנהל לא מוגדר (אופציונלי)")
    
    return True

def test_files():
    """בדיקת קבצים נדרשים"""
    print("📁 בודק קבצים...")
    
    required_files = [USER_DATA_FILE, SIZE_MAP_FILE]
    for file_path in required_files:
        if os.path.exists(file_path):
            print(f"✅ {file_path} קיים")
        else:
            print(f"❌ {file_path} חסר")
            return False
    
    return True

def test_categories():
    """בדיקת קטגוריות ומידות"""
    print("👟 בודק קטגוריות...")
    
    for cat_key, cat_data in CATEGORIES.items():
        print(f"✅ {cat_data['name']}: {len(cat_data['sizes'])} מידות")
    
    return True

def test_user_data():
    """בדיקת נתוני משתמשים"""
    print("👥 בודק נתוני משתמשים...")
    
    try:
        with open(USER_DATA_FILE, 'r', encoding='utf-8') as f:
            users = json.load(f)
        
        print(f"✅ נמצאו {len(users)} משתמשים רשומים")
        
        for user_id, prefs in users.items():
            category = prefs.get('gender', 'לא ידוע')
            size = prefs.get('size', 'לא ידוע')
            price = prefs.get('price', 'לא ידוע')
            print(f"  👤 {user_id}: {category}, מידה {size}, מחיר {price}")
        
        return True
    except Exception as e:
        print(f"❌ שגיאה בקריאת נתוני משתמשים: {e}")
        return False

def main():
    """פונקציה ראשית"""
    print("🧪 מתחיל בדיקת מערכת...")
    print("=" * 50)
    
    tests = [
        ("הגדרות", test_config),
        ("קבצים", test_files),
        ("קטגוריות", test_categories),
        ("נתוני משתמשים", test_user_data)
    ]
    
    passed = 0
    total = len(tests)
    
    for test_name, test_func in tests:
        print(f"\n🔍 בודק {test_name}...")
        if test_func():
            passed += 1
            print(f"✅ {test_name} - עבר")
        else:
            print(f"❌ {test_name} - נכשל")
    
    print("=" * 50)
    print(f"📊 תוצאות: {passed}/{total} בדיקות עברו")
    
    if passed == total:
        print("🎉 כל הבדיקות עברו בהצלחה!")
        print("🚀 הבוט מוכן לשימוש")
    else:
        print("⚠️ יש בעיות שצריך לתקן")
        print("📖 עיין ב-README_PUBLIC.md להוראות")

if __name__ == "__main__":
    main()
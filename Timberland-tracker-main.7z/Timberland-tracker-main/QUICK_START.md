# 🚀 הפעלה מהירה - בוט טימברלנד

## שלב 1: יצירת בוט בטלגרם
1. פתח שיחה עם [@BotFather](https://t.me/botfather)
2. שלח `/newbot`
3. בחר שם לבוט (למשל: "My Timberland Bot")
4. בחר username לבוט (חייב להסתיים ב-bot)
5. שמור את הטוקן שתקבל

## שלב 2: הגדרת הטוקן
```cmd
set TELEGRAM_TOKEN=1234567890:ABCdefGHIjklMNOpqrsTUVwxyz
```

## שלב 3: התקנה אוטומטית
```cmd
python setup.py
```

## שלב 4: הפעלת הבוט
```cmd
python main_bot.py
```

## שלב 5: בדיקה
1. פתח את הבוט בטלגרם
2. שלח `/start`
3. עקב אחר ההוראות

## שלב 6: הפעלת הסריקה (בחלון נפרד)
```cmd
python main_playwright.py
```

## 🔧 פתרון בעיות מהיר

### הבוט לא מגיב?
- בדוק שהטוקן נכון
- וודא שהבוט רץ

### לא מגיעות התראות?
- הפעל את הסריקה: `python main_playwright.py`
- בדוק שיש משתמשים רשומים

### שגיאת Playwright?
```cmd
playwright install chromium
```

## 📞 עזרה נוספת
קרא את [README_PUBLIC.md](README_PUBLIC.md) למידע מפורט.
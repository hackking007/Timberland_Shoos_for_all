#!/usr/bin/env python3
"""
סקריפט התקנה והגדרה ראשונית לבוט טימברלנד
"""

import os
import json
import subprocess
import sys

def check_python_version():
    """בדיקת גרסת Python"""
    if sys.version_info < (3, 7):
        print("❌ נדרשת גרסת Python 3.7 או חדשה יותר")
        return False
    print(f"✅ Python {sys.version_info.major}.{sys.version_info.minor} מותקן")
    return True

def install_requirements():
    """התקנת תלויות"""
    print("📦 מתקין תלויות...")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
        print("✅ תלויות הותקנו בהצלחה")
        return True
    except subprocess.CalledProcessError:
        print("❌ שגיאה בהתקנת התלויות")
        return False

def install_playwright():
    """התקנת דפדפן Playwright"""
    print("🌐 מתקין דפדפן Chromium...")
    try:
        subprocess.check_call([sys.executable, "-m", "playwright", "install", "chromium"])
        print("✅ דפדפן הותקן בהצלחה")
        return True
    except subprocess.CalledProcessError:
        print("❌ שגיאה בהתקנת הדפדפן")
        return False

def create_config_files():
    """יצירת קבצי הגדרה בסיסיים"""
    print("⚙️ יוצר קבצי הגדרה...")
    
    # יצירת user_data.json ריק
    if not os.path.exists("user_data.json"):
        with open("user_data.json", "w", encoding="utf-8") as f:
            json.dump({}, f, ensure_ascii=False, indent=2)
        print("✅ נוצר קובץ user_data.json")
    
    # יצירת shoes_state.json ריק
    if not os.path.exists("shoes_state.json"):
        with open("shoes_state.json", "w", encoding="utf-8") as f:
            json.dump({}, f, ensure_ascii=False, indent=2)
        print("✅ נוצר קובץ shoes_state.json")
    
    return True

def check_token():
    """בדיקת הגדרת טוקן"""
    token = os.environ.get("TELEGRAM_TOKEN")
    if not token:
        print("⚠️ משתנה הסביבה TELEGRAM_TOKEN לא מוגדר")
        print("📝 הגדר אותו באמצעות:")
        print("   Windows: set TELEGRAM_TOKEN=your_token_here")
        print("   Linux/Mac: export TELEGRAM_TOKEN=your_token_here")
        return False
    
    print("✅ טוקן טלגרם מוגדר")
    return True

def main():
    """פונקציה ראשית"""
    print("🚀 מתחיל התקנה של בוט טימברלנד...")
    print("=" * 50)
    
    # בדיקות בסיסיות
    if not check_python_version():
        return False
    
    # התקנת תלויות
    if not install_requirements():
        return False
    
    # התקנת Playwright
    if not install_playwright():
        return False
    
    # יצירת קבצי הגדרה
    if not create_config_files():
        return False
    
    # בדיקת טוקן
    token_ok = check_token()
    
    print("=" * 50)
    if token_ok:
        print("🎉 ההתקנה הושלמה בהצלחה!")
        print("🤖 הפעל את הבוט עם: python main_bot.py")
        print("🔍 הפעל את הסריקה עם: python main_playwright.py")
    else:
        print("⚠️ ההתקנה הושלמה, אך יש להגדיר את טוקן הטלגרם")
        print("📖 קרא את README_PUBLIC.md להוראות מפורטות")
    
    return True

if __name__ == "__main__":
    main()